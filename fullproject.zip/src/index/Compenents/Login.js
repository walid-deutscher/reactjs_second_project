 
import React  from 'react';
 
 
class Login extends  React.Component{

render(){


    return(
        
<div>
  
<div class="w3-border w3-white">
  <div class="w3-container w3-red">
  <h2>Login</h2>
</div>
  <form class="w3-container">
   
   <label>Email</label>
   <input class="w3-input" type="text" /> 
   
   <label>Password</label>
   <input class="w3-input" type="text" /> 
 <br />

 </form>
 <br />

  </div>

 </div>


    
    )
}}


export default Login 




  